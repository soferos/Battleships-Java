
/**
 * Responsible for positioning the ships on the grid
 *
 * @Dominik Szczepaniak
 * @version 1
 */
import java.util.*;

public class BattleGrid 
{
    private final int rows;
    private final int cols;
    private char[][] grid;
    private char[][] shots;
    /**
     * Constructor for objects of class BattleGrid
     */
    public BattleGrid(int rows, int cols)
    {
        this.rows = rows;
        this.cols = cols;
        grid = new char[rows][cols];
        shots = new char[rows][cols]; 
        for (int j = 0; j < rows; j++) 
        for (int k = 0; k< cols; k++)
            shots[j][k] = '-';
    }

    /**
     * this method places the ships on the grid, the arrays are sorted to start with the longest ship
     *
     */
    public void place(Ship[] ships)
    {
        Arrays.sort(ships, new Comparator<Ship>() 
        {
            public int compare(Ship s1, Ship s2) {
                return Integer.valueOf(s1.length).compareTo(Integer.valueOf(s2.length));
            }
        });
    
    
        for (int j = 0; j < rows; j++) 
        for (int k = 0; k< cols; k++)
            grid[j][k] = '-';
            
        char[][] checked = new char[rows][cols];
        Random random = new Random();
        for (int i = ships.length - 1; i >=0; i--) {
            for (int j = 0; j < rows; j++)
                for (int k = 0; k < cols; k++)
                    checked[j][k] = 'O'; //open grid space
            boolean placed = false;
            while (! placed) {
                int r = random.nextInt(rows);
                int c = random.nextInt(cols);
                if (checked[r][c] == 'O') {
                    checked[r][c] = 'C'; //closed position
                    if (grid[r][c] == '-') {
                        int direction = random.nextInt(4);
                        //because there are 4 possible directions, east, west, north, south
                        if(canPlace(ships[i], r, c, direction)) {
                            place(ships[i], r, c, direction);
                            placed = true;
                        }
                    }
                }
            }
        }
    }
    
    /**
     * this method randomises the placement and direction of the ships
     *
     */
    private void place(Ship ship, int row, int col, int direction) {
        int length = ship.getLength();
        char type = ship.getType();
        switch (direction) {
        case 0: //north
            for (int i = row; i >= row - (length - 1); i--)
                grid[col][i] = type;
            break;
        case 1: //south
            for (int i = row; i <= row + (length - 1); i++)
                grid[col][i] = type;
            break;
        case 2: //east
            for (int i = col; i <= col + (length - 1); i++)
                grid[i][row] = type;
            break;
        default: //west
            for (int i = col; i >= col - (length - 1); i--)
                grid[i][row] = type;
            break;
        }
    }
    
    /**
     * this method prevents ships overlapping
     *
     */
    private boolean canPlace(Ship ship, int row, int col, int direction) {
        int length = ship.getLength();
        boolean openSpace = true;
        switch (direction) {
        case 0: //north
            if (row - (length - 1) < 0)
                openSpace = false;
            else
                for (int i = row; i >= row - (length - 1) && openSpace; i--)
                    openSpace = openSpace & (grid[col][i] == '-');
            break;
        
        case 1: //south
            if (row + (length - 1) >= rows)
                openSpace = false;
            else
                for (int i = row; i <= row + (length - 1) && openSpace; i++)
                    openSpace = openSpace & (grid[col][i] == '-');
            break;
        case 2: //east
            if (col + (length - 1) >= cols)
                openSpace = false;
            else
                for (int i = col; i <= col + (length - 1) && openSpace; i++)
                    openSpace = openSpace & (grid[i][row] == '-');
            break;
        default: //west
            if (col - (length - 1) < 0)
                openSpace = false;
            else
                for (int i = col; i >= col - (length - 1) && openSpace; i--)
                    openSpace = openSpace & (grid[i][row] == '-');
            break;
        }
        return openSpace;
    }
    
    /**
     * this method prints the Grid
     *
     */
    public void printGrid() {
        for (int i = 0; i < rows; i++)
            System.out.println(Arrays.toString(grid[i]));
        }
    
    /**
     * this method is responsible for shot firing
     *
     */
    public char handleShot(int row, int col) {
        shots[row][col] = 'x';
        return grid[row][col];
    }
    
    /**
     * this method checks whether the game is over
     *
     */
    public int checkIfGameOver() {
        int result = 19;
        for(int i = 0; i < rows; i++){
            for(int j = 0; j< cols; j++){
                if (grid[i][j] != '-' && shots[i][j] == 'x') {
                    result--;
                }
            } 
        }
            
        return result; 
    }
    
    /**
     * this method returns the value of shots
     *
     */
    public char[][] getShots() {
        return shots;
    }
    
    /**
     * this method returns the value of grid
     *
     */
    public char[][] getGrid() {
        return grid;
    }
    
    public void setShots(char[][] shots) {
          this.shots = shots;
    }
    
    public void setGrid(char[][] grid) {
          this.grid = grid;
    }
}
