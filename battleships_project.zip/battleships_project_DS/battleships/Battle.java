
/**
 * main class executing the game
 *
 * @author Dominik Szczepaniak
 * @version 1
 */
public class Battle
{
    // instance variables - replace the example below with your own
    private int x;
    private BattleGrid battleGrid;
    /**
     * Constructor for objects of class main
     */
    public Battle(int gridSize)
    {
        // initialise instance variables
        Ship[] ships = new Ship[] {
            new Ship(4),
            new Ship(3),
            new Ship(3),
            new Ship(2),
            new Ship(2),
            new Ship(2),
            new Ship(1),
            new Ship(1),
            new Ship(1)
        };
        battleGrid = new BattleGrid(gridSize, gridSize);
        battleGrid.place(ships);
    }
    
    
    /**
     * This method returns handleShot() method from BattleGrid to be used within BattleGui
     * 
     * 
     */
    public char getBattleGridType(int row, int col)
    { 
        return battleGrid.handleShot(row, col);
    }
    
    /**
     * This method returns checkIfGameOver() method from BattleGrid to be used within BattleGui
     */
    public int checkIfGameOver() {
        return battleGrid.checkIfGameOver();
    }
    
    /**
     * This method returns the battleGrid() from BattleGrid to be used within BattleGui
     */
    public BattleGrid getBattleGrid() {
        return battleGrid;
    }
}