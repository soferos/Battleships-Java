
/**
 * This class stores information about different ship sizes and types.
 *
 * @Dominik Szczepaniak
 * @version 1
 */
public class Ship
{
    // instance variables - replace the example below with your own
    int length;
    char type;

    /**
     * Constructor for objects of class ship
     */
    public Ship(int length)
    {
        this.length = length;
        if (length == 4)
            this.type = 'B'; //battleship
        if (length == 3)
            this.type = 'C'; //cruiser
        if (length == 2)
            this.type = 'D'; //destroyer
        if (length == 1)
            this.type = 'S'; //submarine
    }

    /**
     * This method returns the ship length
     *
     * 
     * @return    length
     */
    public int getLength()
    {
        return length;
    }
    
    /**
     * This method returns the ship type
     *
     * 
     * @return    type
     */
    public char getType()
    {
        return type;
    }
}
